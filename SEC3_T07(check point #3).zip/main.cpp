#include "game.h"

int counter = 0;

int main()
{

	//Create an object of controller
	game Game;
	
	Game.run();
	
	return 0;
}

